# 任意端口波导弯曲连接

本工程提供多种连接任意输入、输出端口位姿的波导弯曲算法。端口由位置和传播方向 `(x, y, θ)` 描述，支持对称单弯、普通 S-bend、固定半径比例 S-bend，以及 Euler–Arc–Euler 对称弯曲。

## 环境要求

- MATLAB R2022a 或兼容版本。
- Optimization Toolbox：cubic S-bend 求解使用 `fmincon`。
- 运行目录需要具有 PNG 写入权限。

## 文件说明

- `demo_single_bend_arbitrary_pose.m`：严格对称的单次 cubic 弯曲，曲率为 `0 → ±1/R → 0`。
- `demo_sbend_arbitrary_pose.m`：两次反向 cubic 弯曲，曲率为 `0 → +κ → 0 → -κ → 0`，中间直段长度为零。
- `demo_cubic_ratio_sbend.m`：两段半径带固定比例的 cubic S-bend，使用 `radius_ratio = R2/R1` 调节非对称程度。
- `demo_euler_arc_sym_sweep.m`：对称 Euler–Arc–Euler 单弯，通过遍历并细化 `arc_angle` 完成连接。
- `Wcli_wg.m`：波导类及 bend 生成算法。
- `Wcli_poly.m`：`Wcli_wg` 的父类。

## 运行方法

在 MATLAB 中进入本目录，然后运行任意 demo，例如：

```matlab
cd('工程目录的完整路径');
run('demo_cubic_ratio_sbend.m');
```

也可以直接在 MATLAB 编辑器中打开 demo 并点击“运行”。每个 demo 会自动把自身目录加入 MATLAB 路径。

## 主要参数

端口位姿统一表示为：

```matlab
pose_1 = [x1, y1, theta1];
pose_2 = [x2, y2, theta2];
```

其中位置单位为 `μm`，角度单位为弧度。

常用设置：

```matlab
R_min = 20;          % 要求的最小弯曲半径，单位 μm
radius_ratio = 2;    % ratio S-bend 中 R2/R1
wg_width = 1.2;      % 波导宽度，单位 μm
N_per_section = 401; % 每段采样点数
```

`radius_ratio = 1` 对应两段相同半径；`radius_ratio = 2` 表示第二段半径为第一段的两倍。

## 直接调用库

Single bend 或普通 S-bend：

```matlab
[wg, result] = Wcli_wg.cubic_pose_bend_gen( ...
    'single', pose_1, pose_2, R_min, 401, 1.2, 70, 0.25);

[wg, result] = Wcli_wg.cubic_pose_bend_gen( ...
    'sbend', pose_1, pose_2, R_min, 401, 1.2, 70, 0.25);
```

固定半径比例的 S-bend：

```matlab
[wg, result] = Wcli_wg.cubic_ratio_sbend_gen( ...
    pose_1, pose_2, R_min, radius_ratio, 401, 1.2, 70, 0.25);
```

库函数正常成功时保持静默。若指定的 `R_min` 无法满足，求解器会自动缩小有效半径并继续生成，同时显示醒目的 `R_MIN REQUIREMENT VIOLATED` 警告。此时：

```matlab
result.radius_constraint_met == false
```

这表示结果不满足原先的损耗约束，需要检查实际半径后再使用。

## 输出文件

demo 会在本目录生成波导形状图和曲率图 PNG。Euler–Arc demo 还会生成 `arc_angle` 搜索过程图。

库文件本身不会创建 figure 或 PNG；所有绘图和文件输出均位于四个 demo 中。
